require('dotenv').config()

console.log(`PANEL_DOMAIN: ${process.env.PANEL_URL}`);
console.log(`SUBLINK_DOMAIN: ${process.env.SUB_URL}`);